### TODO

#### Features to be implemented related to renderers and player

*All items listed in https://github.com/mediaelement/mediaelement/labels/Feature*

**NOTE** Please make sure any features are labeled with `Feature` to make them available with the link above.

#### Known issues related to renderers and player

*Known issues to be resolved listed in https://github.com/mediaelement/mediaelement/labels/Bug*

**NOTE** Please make sure any bugs are labeled with `Bug` to make them available with the link above.

### Any features/issues related to elements in controlbar or additional

*All items listed in https://github.com/mediaelement/mediaelement-plugins/issues*
