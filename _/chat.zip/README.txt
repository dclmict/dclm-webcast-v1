A Pen created at CodePen.io. You can find this one at http://codepen.io/supah/pen/jqOBqp.

 It's just a concept, a fake chat to design a new daily ui for direct messaging.
Hope you like it :)